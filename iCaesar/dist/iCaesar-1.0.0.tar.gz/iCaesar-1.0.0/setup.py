__author__ = 'Code Hobbits'

from distutils.core import setup

setup(
    name = 'iCaesar',
    version = '1.0.0',
    py_modules = ['iCaesar'],
    author = 'Your Name',
    author_email = 'yourmail@you.com',
    url = 'http://website.com',
    description = 'Program to encode and decode Caesar Ciphers'
)